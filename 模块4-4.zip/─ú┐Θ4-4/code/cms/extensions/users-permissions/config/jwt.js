module.exports = {
  jwtSecret: process.env.JWT_SECRET || '8324eb12-1c8b-4199-9c22-3825b7eb7630'
};