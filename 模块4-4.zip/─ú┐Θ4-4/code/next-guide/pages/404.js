export default function Error () {
  return <div>404 ~</div>
}