# 计爱玲 Part 4 模块四 React 服务端渲染专题（原生实现、Next.js 集成框架、Gatsby）

作业地址：https://gitee.com/jiailing/lagou-fed/tree/master/fed-e-task-04-04/code/google